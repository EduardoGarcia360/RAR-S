#ifndef NODOE_H
#define NODOE_H

#include <QString>
#include <QStringList>

typedef struct NodoE NodoE;

struct NodoE{
    QString descrip;
    QString token;
    QString linea;
};

#endif // NODOE_H
