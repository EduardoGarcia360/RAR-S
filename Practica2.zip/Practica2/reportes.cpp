#include "reportes.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <iostream>

using namespace std;

void rep_lexicos(QList<NodoE *> lexicos){
    QString head = "<html><head><title>Lexicos</title></head><body style=\"background:#CCC\"><p><br/><br/><br/><br/>\n";
    QString tabla = "<center><h2><font color=\"green\"> Reporte de Errores Lexicos</font></h2><br/><br/><table bordercolor=\"blue\" rules=\"all\">\n";
    tabla+="<tr><td>Texto</td><td>Descripcion</td><td>Fila</td></tr>\n";
    foreach(NodoE* l, lexicos){
        tabla+="<tr><td>"+l->token+"</td><td>"+l->descrip+"</td><td>"+l->linea+"</td></tr>\n";
    }
    tabla+="</table>\n</center></p></body></html>";

    QString pagina = head+tabla;
    QFile archivo("/home/eduardo/Documentos/ReporteErrores/Lexicos.html");
    if(!archivo.open(QFile::WriteOnly | QFile::Text)){
        cout << "error al abrir el archivo" << endl;
    }else{
        QTextStream salida(&archivo);
        salida << pagina;
        archivo.flush();
        archivo.close();
    }
}

void rep_sintacticos(QList<NodoE *> sintacticos){
    QString head = "<html><head><title>Sintacticos</title></head><body style=\"background:#CCC\"><p><br/><br/><br/><br/>\n";
    QString tabla = "<center><h2><font color=\"green\"> Reporte de Errores Sintacticos</font></h2><br/><br/><table bordercolor=\"blue\" rules=\"all\">\n";
    tabla+="<tr><td>Texto</td><td>Descripcion</td><td>Fila</td></tr>\n";
    foreach(NodoE* s, sintacticos){
        tabla+="<tr><td>"+s->token+"</td><td>"+s->descrip+"</td><td>"+s->linea+"</td></tr>\n";
    }
    tabla+="</table>\n</center></p></body></html>";

    QString pagina = head+tabla;
    QFile archivo("/home/eduardo/Documentos/ReporteErrores/Sintacticos.html");
    if(!archivo.open(QFile::WriteOnly | QFile::Text)){
        cout << "error al abrir el archivo" << endl;
    }else{
        QTextStream salida(&archivo);
        salida << pagina;
        archivo.flush();
        archivo.close();
    }
}

void rep_semanticos(QList<NodoE *> semanticos){
    QString head = "<html><head><title>Semanticos</title></head><body style=\"background:#CCC\"><p><br/><br/><br/><br/>\n";
    QString tabla = "<center><h2><font color=\"green\"> Reporte de Errores Semanticos</font></h2><br/><br/><table bordercolor=\"blue\" rules=\"all\">\n";
    tabla+="<tr><td>Texto</td><td>Descripcion</td></tr>\n";
    foreach(NodoE* ss, semanticos){
        tabla+="<tr><td>"+ss->token+"</td><td>"+ss->descrip+"</td></tr>\n";
    }
    tabla+="</table>\n</center></p></body></html>";

    QString pagina = head+tabla;
    QFile archivo("/home/eduardo/Documentos/ReporteErrores/Semanticos.html");
    if(!archivo.open(QFile::WriteOnly | QFile::Text)){
        cout << "error al abrir el archivo" << endl;
    }else{
        QTextStream salida(&archivo);
        salida << pagina;
        archivo.flush();
        archivo.close();
    }
}

void rep_vacio(int lss){
    QString tipo;
    if(lss==1){
        tipo="Lexicos";
    }else if(lss==2){
        tipo="Sintacticos";
    }else{
        tipo="Semanticos";
    }

    QString head = "<html><head><title>"+tipo+"</title></head><body style=\"background:#CCC\"><p><br/><br/><br/><br/>";
    QString body = "<center><h2><font color=\"green\"> Reporte de Errores "+tipo+"</font></h2><br/><br/><h1>Archivo sin errores "+tipo+".</h1></center></p></body></html>";
    QString pagina = head+body;
    QFile archivo("/home/eduardo/Documentos/ReporteErrores/"+tipo+".html");
    if(!archivo.open(QFile::WriteOnly | QFile::Text)){
        cout << "error al abrir el archivo" << endl;
    }else{
        QTextStream salida(&archivo);
        salida << pagina;
        archivo.flush();
        archivo.close();
    }
}

void rep_ll1(QList<NodoT*> gramatica){
    QString head="<html><head><title>Salida LL(1)</title></head><body  style=\"background:#CCC\"><p><br/><center><h2><font color=\"green\">Salida LL(1)</font></h2><br/><br/></center>\n";
    QString tabla="<center><br/></p><table bordercolor=\"blue\" rules=\"all\"><tr>\n<td><font color=\"red\">No Terminal</font></td>\n<td><font color=\"red\">Primeros</font></td>\n<td><font color=\"red\">Siguientes</font></td>\n</tr>\n";
    foreach(NodoT* p, gramatica){
        QString prim="(", sig="(";
        int ultimo;
        ultimo=p->primeros.length()-1;
        for(int i=0; i<p->primeros.length(); i++){
            if(i==ultimo){
                prim+=p->primeros.at(i);
            }else{
                prim+=p->primeros.at(i)+", ";
            }
        }
        prim+=")";

        ultimo=p->siguientes.length()-1;
        for(int j=0; j<p->siguientes.length(); j++){
            if(j==ultimo){
                sig+=p->siguientes.at(j);
            }else{
                sig+=p->siguientes.at(j)+", ";
            }
        }
        sig+=")";

        tabla+="<tr><td>"+p->no_terminal+"</td><td>"+prim+"</td><td>"+sig+"</td></tr>\n";
    }

    QString pagina=head+tabla+"</table><br/></center></body></html>";
    QFile archivo("/home/eduardo/Documentos/ll1.html");
    if(!archivo.open(QFile::WriteOnly | QFile::Text)){
        cout << "error al abrir el archivo" << endl;
    }else{
        QTextStream salida(&archivo);
        salida << pagina;
        archivo.flush();
        archivo.close();
    }
}

















