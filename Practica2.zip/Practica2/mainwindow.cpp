#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "nodoe.h"
#include "nodot.h"
#include "parser.h"
#include "semantico.h"
#include "reportes.h"
#include "ll1.h"
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <fstream>
#include <QFile>
#include <QTextStream>
#include <QFileDialog>
#include <QMessageBox>
#include <QList>
#include <QPalette>
#include <QDesktopServices>
#include <QUrl>

QList<NodoT *> produccion;
QStringList terminales_generales;
QStringList noterminales_generales;
QString ruta_archivo_abierto;
extern int yyparse();
extern void inicializa (QPlainTextEdit *pte, QLabel *res, QList<NodoT*> prod, QStringList ter_gen, QStringList noter_gen);
extern FILE *yyin;
extern QList<NodoE*> getLexicos();
extern QList<NodoE*> getSintacticos();

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPalette paleta = ui->lblPOSICION->palette();
    paleta.setColor(ui->lblPOSICION->foregroundRole(), Qt::yellow);
    ui->lblPOSICION->setPalette(paleta);
    ui->lblPOSICION->setText("Fila: 0\tColumna: 0");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pteCODIGO_cursorPositionChanged()
{
    int fila = ui->pteCODIGO->textCursor().blockNumber();
    int columna = ui->pteCODIGO->textCursor().columnNumber();
    ui->lblPOSICION->setText("Fila: " + QString::number(fila) + "\tColumna: "+ QString::number(columna));
}

void MainWindow::on_actionAbrir_Gramatica_triggered()
{
    QString filtro = "Text File (*.txt)";
    QString nombre_archivo = QFileDialog::getOpenFileName(this, "Abre una gramatica", "/home/eduardo/", filtro);
    ruta_archivo_abierto=nombre_archivo;
    if(!nombre_archivo.isEmpty()){
        QFile archivo(nombre_archivo);
        if(archivo.open(QFile::ReadOnly | QFile::Text)){
            QTextStream entrada(&archivo);
            QString texto = entrada.readAll();
            ui->pteCODIGO->setPlainText(texto);
            archivo.close();
        }else{
            QMessageBox::warning(this, "Error", "Archivo no encontrado");
        }
    }
}

void MainWindow::on_actionAnalizar_triggered()
{
    inicializa(ui->pteCODIGO, ui->lblRESULTADO, produccion, terminales_generales, noterminales_generales);
    if(ui->pteCODIGO->toPlainText().length() > 0){
        crearArchivo(ui->pteCODIGO->toPlainText());
        yyin=fopen("entrada.txt", "rt");
        if(!yyin){
            QMessageBox::warning(this, "Error", "Imposible abrir el archivo.");
        }else{
            yyparse();
        }
    }

}

void MainWindow::crearArchivo(QString texto){
    ofstream archivo;
    archivo.open("entrada.txt", ios::out);
    archivo << texto.toStdString() << endl;
    archivo.close();
}

void MainWindow::on_actionErrores_triggered()
{
    QList<NodoE*> l = getLexicos();
    QList<NodoE*> s = getSintacticos();
    QList<NodoE*> ss = getSemanticos();

    if(l.length()>0){
        rep_lexicos(l);
    }else{
        rep_vacio(1);
    }

    if(s.length()>0){
        rep_sintacticos(s);
    }else{
        rep_vacio(2);
    }

    if(ss.length()>0){
        rep_semanticos(ss);
    }else{
        rep_vacio(3);
    }

    QDesktopServices::openUrl(QUrl::fromLocalFile("/home/eduardo/Documentos/ReporteErrores/MasterPage.html"));
}

void MainWindow::on_actionReporte_triggered()
{
    QList<NodoT*> ll = getGramatica();
    rep_ll1(ll);
    QDesktopServices::openUrl(QUrl::fromLocalFile("/home/eduardo/Documentos/ll1.html"));
}

void MainWindow::on_actionGuardar_Gramatica_triggered()
{
    if(ruta_archivo_abierto.isEmpty()){
        QMessageBox::warning(this, "Error", "Debes abrir un archivo primero.");
    }else{
        QFile abierto(ruta_archivo_abierto);
        if(!abierto.open(QFile::WriteOnly | QFile::Text)){
            QMessageBox::warning(this, "Error", "Imposible abrir el archivo.");
        }else{
            QTextStream salida(&abierto);
            QString nuevo = ui->pteCODIGO->toPlainText();
            salida << nuevo;
            abierto.flush();
            abierto.close();
        }
    }
}
