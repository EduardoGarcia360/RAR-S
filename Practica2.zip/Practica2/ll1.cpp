#include "ll1.h"
#include "nodot.h"
#include <QList>
#include <QStringList>
#include <iostream>

using namespace std;

NodoT* getProduccion(QList<NodoT *> GRAMATICA, QString buscado);
QList<NodoT*> getApariciones(QList<NodoT*> GRAMATICA, QString buscado);
int ester(QString t);
int esnoter(QString nt);
QString ver_primero(QList<NodoT*> GRAMATICA, QString no_ter_actual);
void actualizar_gramatica(QStringList nuevo, QString nt);
void verSiguientes(QString noter_buscado, QString inicio, QList<NodoT*> apariciones);
int contiene_epsilon(QString noter);
QStringList getPrim(QString Buscado);
QStringList getSig(QString buscado);

QStringList ll1noter_generales;
QStringList ll1ter_generales;
QList<NodoT*> gra_con_primsig;
QList<NodoT*> lista_apariciones;

void ll1(QStringList noter, QStringList ter){
    ll1noter_generales=noter;
    ll1ter_generales=ter;
    ll1ter_generales << "epsilon";
}

void actualizar_gramatica(QStringList nuevo, QString nt){
    foreach(NodoT* p, gra_con_primsig){
        if(p->no_terminal==nt){
            p->primeros=nuevo;
            break;
        }
    }
}

void actualizar_siguientes(QStringList nuevo, QString nt){
    foreach(NodoT* p, gra_con_primsig){
        if(p->no_terminal==nt){
            //codigo anterior
            //p->siguientes<<nuevo;
            //codigo nuevo
            for(int i=0; i<nuevo.length(); i++){
                if(!p->siguientes.contains(nuevo.at(i))){
                    p->siguientes << nuevo.at(i);
                }
            }
            break;
        }
    }
}

int ester(QString t){
    for(int j=0; j<ll1ter_generales.length(); j++){
        if(t==ll1ter_generales.at(j) || strcasecmp(t.toLatin1().constData(), "epsilon")==0){
            return 1;
        }
    }
    return 0;
}

int esnoter(QString nt){
    for(int i=0; i<ll1noter_generales.length(); i++){
        if(nt==ll1noter_generales.at(i)){
            return 1;
        }
    }
    return 0;
}

NodoT* getProduccion(QList<NodoT *> GRAMATICA, QString buscado){
    foreach(NodoT* G, GRAMATICA){
        if(G->no_terminal==buscado){
            return G;
        }
    }
}

QList<NodoT*> getApariciones(QList<NodoT*> GRAMATICA, QString buscado){
    lista_apariciones.clear();
    foreach(NodoT* G, GRAMATICA){
        foreach(QString pro, G->producciones){
            if(pro==buscado){
                lista_apariciones << G;
                break;
            }
        }
    }
    return lista_apariciones;
}

void encontrar_primeros(QList<NodoT *> GRAMATICA, QString inicio){
    gra_con_primsig=GRAMATICA;
    NodoT* prod_inicio = getProduccion(GRAMATICA, inicio);

    QString retornado = ver_primero(GRAMATICA, prod_inicio->no_terminal);
    prod_inicio->primeros << retornado.split(",");

    actualizar_gramatica(prod_inicio->primeros, prod_inicio->no_terminal);

    //cout << "de: " << prod_inicio->no_terminal.toStdString() << "-" << retornado.toStdString() <<endl;

    foreach (NodoT* p, GRAMATICA) {
        if(p->no_terminal!=prod_inicio->no_terminal){
            //diferente a la produccion ya hecha, osea a la inicial
            QString primeros = ver_primero(GRAMATICA, p->no_terminal);
            p->primeros << primeros.split(",");

            actualizar_gramatica(p->primeros, p->no_terminal);
            //cout << "de: "<< p->no_terminal.toStdString() << "-" << primeros.toStdString() <<endl;
        }
    }
    //cout << "/****************************/" <<endl;
}

QString ver_primero(QList<NodoT *> GRAMATICA, QString no_ter_actual){
    NodoT* noter_prod_actual = getProduccion(GRAMATICA, no_ter_actual);
    QString recibe_algo="";
    /*
     * Se valida que el primero de la produccion sea un terminal
     */
    if(ester(noter_prod_actual->producciones.at(0)) == 1){
        //el primero es un 'terminal'
        recibe_algo=noter_prod_actual->producciones.at(0);
        /*reviso el resto de la produccion buscando un OR ("|")
         * luego reviso el siguiente de ese OR para ver si es un 'terminal'
         * o un 'no terminal'
         */
        for(int i=1; i<noter_prod_actual->producciones.length(); i++){
            if(noter_prod_actual->producciones.at(i)=="|"){
                if(ester(noter_prod_actual->producciones.at(i + 1)) == 1){
                    recibe_algo+=","+noter_prod_actual->producciones.at(i + 1);
                    i++;
                }else{
                    recibe_algo+=","+ver_primero(GRAMATICA, noter_prod_actual->producciones.at(i + 1));
                    i++;
                }
            }
        }
    }else{
        //el primero es un 'no terminal'
        recibe_algo = ver_primero(GRAMATICA, noter_prod_actual->producciones.at(0));
        //agregue esto alv
        for(int i=1; i<noter_prod_actual->producciones.length(); i++){
            if(noter_prod_actual->producciones.at(i)=="|"){
                if(ester(noter_prod_actual->producciones.at(i + 1)) == 1){
                    recibe_algo+=","+noter_prod_actual->producciones.at(i + 1);
                    i++;
                }else{
                    recibe_algo+=","+ver_primero(GRAMATICA, noter_prod_actual->producciones.at(i + 1));
                    i++;
                }
            }
        }
    }
    return recibe_algo;
}

void encontrar_siguientes(QString inicio){
    foreach(NodoT* G, gra_con_primsig){
        /*
         * se buscan todas las apariciones de los 'no terminales' de la gramatica
         * en 'apariciones' se almacenan en forma de lista las producciones que
         * contienen al 'no terminal' buscado
         */
        QList<NodoT*> apariciones = getApariciones(gra_con_primsig, G->no_terminal);
        if(apariciones.length()==0){
            //sin apariciones puede ser el inicio o un notermianl no usado
            if(G->no_terminal==inicio){
                QStringList ssr1;
                ssr1 << "$";
                actualizar_siguientes(ssr1, inicio);
            }else{
                QStringList nousado;
                nousado << "/*Nada*/";
                actualizar_siguientes(nousado, inicio);
            }
        }else{
            verSiguientes(G->no_terminal, inicio, apariciones);
        }
    }
    /*
    cout<<"**mostrando siguientes**"<<endl;
    foreach(NodoT* si, gra_con_primsig){
        cout<<"de: "<<si->no_terminal.toStdString()<<endl;
        foreach(QString sig, si->siguientes){
            cout<<sig.toStdString()<<endl;
        }
        cout<<"--------------"<<endl;
    }
    */
}

void verSiguientes(QString noter_buscado, QString inicio, QList<NodoT*> apariciones){
    foreach(NodoT* aparicion, apariciones){
        int tam = aparicion->producciones.length();
        for(int i=0; i<aparicion->producciones.length(); i++){
            if(noter_buscado==aparicion->producciones.at(i)){
                if(noter_buscado==inicio){
                    //Regla 1: 'inicie con 'no terminal'
                    QStringList ssr1;
                    ssr1 << "$";
                    actualizar_siguientes(ssr1, noter_buscado);
                }

                int sig_pos=i+1;
                int ant_pos=i-1;
                if(ant_pos>=0 && sig_pos<tam && aparicion->producciones.at(i+1)!="|"){
                    /*Regla 3:
                     * ej1. E->mas T E' ...
                     * ej2. E->apar T cpar ...
                     * donde T es el 'noter_buscado'
                     * aparicion->producciones.at(i-1)!=NULL
                     * aparicion->producciones.at(i+1)!=NULL
                     */
                    if(contiene_epsilon(aparicion->producciones.at(i+1))==1){
                        /*Regla 3.1:
                         * siguiendo con el ej1.
                         * los primeros de E' sí contienen a epsilon
                         * S(T) = P(E') + S(E)
                         */
                        QStringList pri = getPrim(aparicion->producciones.at(i+1));
                        QStringList sig = getSig(aparicion->no_terminal);
                        QStringList unido;
                        unido << pri;
                        unido << sig;
                        actualizar_siguientes(unido, noter_buscado);
                    }else{
                        /*Regla 3.2:
                         * siguiendo con el ej2.
                         * al ser cpar un terminal solo se agrega
                         * S(T) = cpar
                         */
                        QStringList ss;
                        ss << aparicion->producciones.at(i+1);
                        actualizar_siguientes(ss, noter_buscado);
                    }
                }else if(ant_pos>=0 && sig_pos<tam && aparicion->producciones.at(i+1)=="|"){
                    /*Regla 2:
                     * ej. E->mas T W | menos T W2;
                     * donde W es el 'noter_buscado'
                     * entonces: S(W) = S(E)
                     * aparicion->producciones.at(i-1)!=NULL
                     * aparicion->producciones.at(i+1)!=NULL
                     */
                    if(noter_buscado!=aparicion->no_terminal){
                        //para no agregar los siguientes de él mismo
                        QStringList sr2 = getSig(aparicion->no_terminal);
                        actualizar_siguientes(sr2, noter_buscado);
                    }
                }else if(ant_pos>=0 && sig_pos==tam){
                    /*Regla 2:
                     * ej. E->T W;
                     * donde W es el 'noter_buscado'
                     * entonces: S(W) = S(E)
                     * aparicion->producciones.at(i-1)!=NULL
                     * aparicion->producciones.at(i+1)==NULL
                     */
                    if(noter_buscado!=aparicion->no_terminal){
                        //para no agregar los siguientes de él mismo
                        QStringList ssr2 = getSig(aparicion->no_terminal);
                        actualizar_siguientes(ssr2, noter_buscado);
                    }
                }else if(ant_pos<=0){
                    /*Regla 2:
                     * ej. S->E;
                     * donde E es el 'noter_buscado'
                     * entonces: S(E) = S(S)
                     * aparicion->producciones.at(i-1)==NULL
                     */
                    if(noter_buscado!=aparicion->no_terminal){
                        //para no agregar los siguientes de él mismo
                        QStringList s = getSig(aparicion->no_terminal);
                        actualizar_siguientes(s, noter_buscado);
                    }
                }
            }
        }
    }
}

QStringList getPrim(QString Buscado){
    QStringList sin_epsilon;
    foreach(NodoT* p, gra_con_primsig){
        if(p->no_terminal==Buscado){
            foreach(QString prim, p->primeros){
                if(strcasecmp(prim.toLatin1().constData(), "epsilon")!=0){
                    sin_epsilon << prim;
                }
            }
            break;
        }
    }
    return sin_epsilon;
}

QStringList getSig(QString buscado){
    foreach(NodoT* p, gra_con_primsig){
        if(p->no_terminal==buscado){
            return p->siguientes;
        }
    }
}

int contiene_epsilon(QString noter){
    foreach(NodoT* p, gra_con_primsig){
        if(p->no_terminal==noter){
            foreach(QString pri, p->primeros){
                if(strcasecmp(pri.toLatin1().constData(), "epsilon")==0){
                    return 1;
                }
            }
        }
    }
    return 0;
}

QList<NodoT*> getGramatica(){
    return gra_con_primsig;
}
