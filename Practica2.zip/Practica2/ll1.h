#ifndef LL1_H
#define LL1_H
#include <QList>
#include "nodot.h"

void ll1(QStringList noter, QStringList ter);
void encontrar_primeros(QList<NodoT*> GRAMATICA, QString inicio);
void encontrar_siguientes(QString inicio);
QList<NodoT*> getGramatica();

#endif // LL1_H
