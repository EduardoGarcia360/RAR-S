#ifndef SEMANTICO_H
#define SEMANTICO_H
#include <QStringList>
#include <QList>
#include "nodot.h"
#include "nodoe.h"

void terminales_repetidos(QStringList ter);
void noterminales_repetidos(QStringList noter);
void ter_noter_repetidos(QStringList ter, QStringList noter);
void recursiva_izq(QList<NodoT*> producciones);
void no_declarados(QStringList ter, QStringList noter, QList<NodoT*> producciones);
int es_noter(QString nt, QStringList noter);
void limpiar_lista();
QList<NodoE*> getSemanticos();
void mostrar_semanticos();
void insertar_error(NodoE* n_error);

#endif // SEMANTICO_H
