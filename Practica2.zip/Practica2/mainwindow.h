#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPlainTextEdit>
#include <QList>
#include <QStringList>
#include <QLabel>
#include "nodot.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void crearArchivo(QString texto);

private slots:

    void on_pteCODIGO_cursorPositionChanged();

    void on_actionAbrir_Gramatica_triggered();

    void on_actionAnalizar_triggered();

    void on_actionErrores_triggered();

    void on_actionReporte_triggered();

    void on_actionGuardar_Gramatica_triggered();

private:
    Ui::MainWindow *ui;
    QPlainTextEdit *pteCODIGO;
    QLabel *lblRESULTADO;
  QList<NodoT*> PRODUCCION;
  QStringList ter_generales;
  QStringList noter_generales;
  QString noter_inicio;
};

#endif // MAINWINDOW_H
