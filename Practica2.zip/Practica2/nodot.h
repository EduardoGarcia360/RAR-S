#ifndef NODOT_H
#define NODOT_H
#include <QString>
#include <QStringList>

typedef struct NodoT NodoT;

struct NodoT{
    QString no_terminal;
    QStringList producciones;
    QStringList primeros;
    QStringList siguientes;
};

#endif // NODOT_H
