#ifndef REPORTES_H
#define REPORTES_H
#include <nodoe.h>
#include <nodot.h>
#include <QList>

void rep_lexicos(QList<NodoE*> lexicos);
void rep_sintacticos(QList<NodoE*> sintacticos);
void rep_semanticos(QList<NodoE*> semanticos);
void rep_vacio(int lss);
void rep_ll1(QList<NodoT*> gramatica);

#endif // REPORTES_H
