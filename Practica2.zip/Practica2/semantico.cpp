#include "semantico.h"
#include "nodot.h"
#include "nodoe.h"
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <QStringList>

QStringList Semantico_ternoter_repetidos;
QList<NodoE*> SEMANTICOS;
NodoE* nuevo_error;
int es_ter(QString t, QStringList ter);
using namespace std;

void limpiar_lista(){
    SEMANTICOS.clear();
}

void terminales_repetidos(QStringList ter){
    for(int i=0; i<ter.length(); i++){
        for(int j=0; j<ter.length(); j++){
            if(ter.at(i)==ter.at(j) && i!=j){
                nuevo_error=new NodoE;
                nuevo_error->token=ter.at(i);
                nuevo_error->descrip="Terminal declarado mas de una vez.";

                SEMANTICOS << nuevo_error;
                break;
            }
        }
    }
}

void noterminales_repetidos(QStringList noter){
    for(int i=0; i<noter.length(); i++){
        for(int j=0; j<noter.length(); j++){
            if(noter.at(i)==noter.at(j) && i!=j){
                nuevo_error=new NodoE;
                nuevo_error->token=noter.at(i);
                nuevo_error->descrip="No terminal declarado mas de una vez.";

                SEMANTICOS << nuevo_error;
                break;
            }
        }
    }
}

void ter_noter_repetidos(QStringList ter, QStringList noter){
    for(int i=0; i<ter.length(); i++){
        for(int j=0; j<noter.length(); j++){
            if(ter.at(i) == noter.at(j)){
                nuevo_error=new NodoE;
                nuevo_error->token=ter.at(i);
                nuevo_error->descrip="Mismo nombre para un terminal y un no terminal.";

                SEMANTICOS << nuevo_error;
                break;
            }
        }
    }
}

void recursiva_izq(QList<NodoT *> producciones){
    foreach(NodoT* pro, producciones){
        for(int i=0; i<pro->producciones.length(); i++){
            if(pro->no_terminal==pro->producciones.at(0)){
                nuevo_error=new NodoE;
                nuevo_error->token=pro->producciones.at(0);
                nuevo_error->descrip="No puede haber recursividad por la izquierda.";

                SEMANTICOS << nuevo_error;
            }else if(pro->producciones.at(i)=="|"){
                if(pro->producciones.at(i+1)==pro->no_terminal){
                    nuevo_error=new NodoE;
                    nuevo_error->token=pro->producciones.at(0);
                    nuevo_error->descrip="No puede haber recursividad por la izquierda.";

                    SEMANTICOS << nuevo_error;
                }
            }
        }
    }
}

void no_declarados(QStringList ter, QStringList noter, QList<NodoT *> producciones){
    foreach(NodoT* nodo, producciones){
        if(es_ter(nodo->no_terminal, ter)==1){
            //es un 'terminal' para la produccion
            nuevo_error = new NodoE;
            nuevo_error->descrip="Uso de terminal incorrecto, se esperaba un no terminal.";
            nuevo_error->token=nodo->no_terminal;

            SEMANTICOS << nuevo_error;
        }

        foreach(QString p, nodo->producciones){
            if(es_noter(p, noter)==0){
                if(es_ter(p, ter)==0){
                    nuevo_error = new NodoE;
                    nuevo_error->descrip="Terminal/No terminal no declarado.";
                    nuevo_error->token=p;

                    SEMANTICOS << nuevo_error;
                }
            }
        }
    }
}

void mostrar_semanticos(){
    foreach(NodoE* e, SEMANTICOS){
        cout<<e->token.toStdString()<<"//"<<e->descrip.toStdString()<<endl;
    }
    cout<<"/*---------------------------------------*/"<<endl;
}

QList<NodoE*> getSemanticos(){
    return SEMANTICOS;
}

int es_ter(QString t, QStringList ter){
    for(int j=0; j<ter.length(); j++){
        if(t==ter.at(j)){
            return 1;
        }else if(t=="|" || strcasecmp(t.toLatin1().constData(), "epsilon")==0){
            return 1;
        }
    }
    return 0;
}

int es_noter(QString nt, QStringList noter){
    for(int i=0; i<noter.length(); i++){
        if(nt==noter.at(i) && nt!="|"){
            return 1;
        }else if(nt=="|" || strcasecmp(nt.toLatin1().constData(), "epsilon")==0){
            return 1;
        }
    }
    return 0;
}

void insertar_error(NodoE* n_error){
    SEMANTICOS << n_error;
}
